# kream-miniproject

## 프로젝트 구성도
![network](./img/network_v1.0.png)

## ERD
![network](./img/erd_v1.0.png)