package user.service;

public class UserSelectService implements UserService {

	@Override
	public void execute() {
		System.out.println();
		System.out.println("select");
	}
}
