package kream.bean;

import java.time.LocalDateTime;

import org.springframework.stereotype.Repository;

import lombok.Getter;
import lombok.Setter;

@Repository
@Setter
@Getter
public class ProductDTO {
	private int productId;
    private String category;
    private String category2;
    private String brand;
    private String productName;
    private String productExplain;
    private String productDetail;
    private int price;
    private String option;
    private String productImg;
    private int stock;
    private String productColor;
    private int hit;
    private LocalDateTime createdDate;
    private LocalDateTime releaseDate;
    private String size;
}
